#include <windows.h>
#include <mmsystem.h>
#include <fstream>
#include <string>
#include <map>

typedef std::map<UINT, std::string> SoundMap;

SoundMap soundMapping;
HHOOK mouseHook = NULL;
NOTIFYICONDATA nidApp;
HINSTANCE hInst;

#define WM_TRAYICON (WM_USER + 1)
#define IDM_EXIT 1001

LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0) {
        MSLLHOOKSTRUCT* pMouseStruct = reinterpret_cast<MSLLHOOKSTRUCT*>(lParam);
        
        switch(wParam) {
            case WM_LBUTTONDOWN:
                if (soundMapping.find(WM_LBUTTONDOWN) != soundMapping.end()) {
                    PlaySound(soundMapping[WM_LBUTTONDOWN].c_str(), NULL, SND_FILENAME | SND_ASYNC);
                }
                break;
            case WM_RBUTTONDOWN:
                if (soundMapping.find(WM_RBUTTONDOWN) != soundMapping.end()) {
                    PlaySound(soundMapping[WM_RBUTTONDOWN].c_str(), NULL, SND_FILENAME | SND_ASYNC);
                }
                break;
            case WM_MBUTTONDOWN:
                if (soundMapping.find(WM_MBUTTONDOWN) != soundMapping.end()) {
                    PlaySound(soundMapping[WM_MBUTTONDOWN].c_str(), NULL, SND_FILENAME | SND_ASYNC);
                }
                break;
        }
    }
    return CallNextHookEx(mouseHook, nCode, wParam, lParam);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_DESTROY:
            UnhookWindowsHookEx(mouseHook);
            Shell_NotifyIcon(NIM_DELETE, &nidApp);
            PostQuitMessage(0);
            break;
        case WM_TRAYICON: {
            if (LOWORD(lParam) == WM_LBUTTONUP) {
                // Handle left-click on tray icon
            } else if (LOWORD(lParam) == WM_RBUTTONUP) {
                POINT pt;
                GetCursorPos(&pt);
                SetForegroundWindow(hwnd);

                HMENU hMenu = CreatePopupMenu();
                AppendMenu(hMenu, MF_STRING | MF_GRAYED, 1, "Mouse Sound");
                AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
                AppendMenu(hMenu, MF_STRING, IDM_EXIT, "Exit");

                TrackPopupMenu(hMenu, TPM_RIGHTALIGN | TPM_BOTTOMALIGN, pt.x, pt.y, 0, hwnd, NULL);
                PostMessage(hwnd, WM_NULL, 0, 0);
            }
            break;
        }
        case WM_COMMAND: {
            switch (LOWORD(wParam)) {
                case IDM_EXIT:
                    SendMessage(hwnd, WM_DESTROY, 0, 0);
                    break;
            }
            break;
        }
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

void usage() {
    printf("Usage: mouse_sound.exe [config_file]\n");
    printf("Example: mouse_sound.exe settings.conf\n");
    exit(1);
}

bool loadConfig(const std::string& configFile) {
    std::ifstream file(configFile.c_str());
    if (!file.is_open()) {
        printf("Failed to open configuration file: %s\n", configFile.c_str());
        return false;
    }

    std::string line;
    while (std::getline(file, line)) {
        size_t equalsPos = line.find('=');
        
        if (equalsPos == std::string::npos || equalsPos == 0 || equalsPos == line.length() - 1) {
            printf("Invalid configuration line: %s\n", line.c_str());
            continue;
        }
        
        std::string button = line.substr(0, equalsPos);
        std::string soundFile = line.substr(equalsPos + 1);

        UINT msg = 0;
        if (button == "LBUTTON") {
            msg = WM_LBUTTONDOWN;
        } else if (button == "RBUTTON") {
            msg = WM_RBUTTONDOWN;
        } else if (button == "MBUTTON") {
            msg = WM_MBUTTONDOWN;
        } else {
            printf("Invalid mouse button: %s\n", button.c_str());
            continue;
        }
        
        soundMapping[msg] = std::string("sounds/") + soundFile;
    }

    return true;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    (void)hPrevInstance;
    (void)lpCmdLine;

    std::string configFile = "settings.conf";
    if (__argc > 1) {
        configFile = __argv[1];
    }

    if (!loadConfig(configFile)) {
        printf("Configuration file not found. Please specify a valid configuration file.\n");
        usage();
        return -1;
    }

    const char* CLASS_NAME = "MouseSoundClass";
    hInst = hInstance;

    WNDCLASSEX wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = (WNDPROC)WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = CLASS_NAME;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, IDI_APPLICATION);

    if (!RegisterClassEx(&wcex)) {
        printf("Failed to register window class.\n");
        return -1;
    }

    HWND hwnd = CreateWindowEx(0, CLASS_NAME, "Mouse Sound", WS_OVERLAPPEDWINDOW,
                               CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
                               NULL, NULL, hInstance, NULL);

    if (!hwnd) {
        printf("Failed to create window.\n");
        return -1;
    }

    mouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseProc, hInstance, 0);
    
    if (mouseHook == NULL) {
        printf("Failed to install hook. Error code: %d\n", GetLastError());
        return -1;
    }

    memset(&nidApp, 0, sizeof(nidApp));
    nidApp.cbSize = sizeof(NOTIFYICONDATA);
    nidApp.hWnd = hwnd;
    nidApp.uID = 1;
    nidApp.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nidApp.uCallbackMessage = WM_TRAYICON;
    nidApp.hIcon = LoadIcon(NULL, IDI_APPLICATION);

    // Ensure szTip is null-terminated
    strncpy(nidApp.szTip, "Mouse Sound", sizeof(nidApp.szTip) - 1);
    nidApp.szTip[sizeof(nidApp.szTip) - 1] = '\0';

    if (!Shell_NotifyIcon(NIM_ADD, &nidApp)) {
        printf("Failed to add tray icon.\n");
        return -1;
    }

    ShowWindow(hwnd, SW_HIDE); // Hide the window
    UpdateWindow(hwnd);

    MSG msg;
    while(GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    UnhookWindowsHookEx(mouseHook);

    return 0;
}
